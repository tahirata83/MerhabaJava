package selfStudy;

import java.util.Scanner;

public class BeklenmedikDurumlar {
    public static void main(String[] args) {
        Scanner scan=new Scanner(System.in);
        int a=scan.nextInt();
        int b=scan.nextInt();
//        scan.nextLine();
//        String s=scan.nextLine();
// nextInt den sonra nextLine olurs sikinti cikiyor
    }
}
