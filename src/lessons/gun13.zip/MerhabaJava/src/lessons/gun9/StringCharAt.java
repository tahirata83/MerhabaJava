package lessons.gun9;



public class StringCharAt {
    public static void main(String[] args) {
        String s1="Ben Java ogreniyorum";
        //System.out.println(s1.indexOf("J"));
        System.out.println(s1.charAt(4));
        System.out.println(s1.charAt(9));
        System.out.println("===================================");
        System.out.println(s1.charAt(28));

    }
    }

