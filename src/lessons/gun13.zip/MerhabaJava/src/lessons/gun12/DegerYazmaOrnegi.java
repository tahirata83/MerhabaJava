package lessons.gun12;

public class DegerYazmaOrnegi {
    public static void main(String[] args) {
        int s1=3;
        int s2=4;
        int sum=s1+s2;
//        System.out.println((s1+s2));
//        System.out.println("sonuc "+s1+s2);
//        System.out.println("sonuc "+(s1+s2));
        System.out.println(sum);
        System.out.println("toplam "+sum);

    }
}
