package lessons.gun12;

import java.util.Scanner;

public class ScannereDevam {
    public static void main(String[] args) {

        System.out.println("Bir kelime girin:");
     Scanner  degisken= new Scanner(System.in);

          // int sayi= degisken.nextInt();
           String kelime=degisken.nextLine();

            System.out.println(kelime+"!");


    }
}
