package lessons.gun12;

public class MaxBulma {
    public static void main(String[] args) {
        int a= 77;
        int b=32;
        int c=378;

        int max=c;

        // su anda benim max= c

        if(max<b){
             max= b;
        }

        // if sarti dogru ise eger max b den kucuk ise benim max b olur
        // if sarti dogru degilse benim max hala c dir

        if(max<a){
            max=a;
        }

        // if sarti dogru ise eger max a dan kucuk ise benim max a olur
        // if sarti dogru degilse benim max hala c dir

        System.out.println(max);



        int a1=3;
        a1=4;

    }
}
