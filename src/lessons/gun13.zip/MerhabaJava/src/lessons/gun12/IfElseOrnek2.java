package lessons.gun12;

public class IfElseOrnek2 {
    public static void main(String[] args) {
        int a=21;
        String s="Ben Java Kullaniyorum.";

        if(a==s.length()){
            System.out.println("Kelimenin karakter sayisi int sayiya esittir");
        }else{
            System.out.println("Kelimenin karakter sayisi int sayiya esit degildir");
        }
    }
}
