package lessons.gun12;

import java.util.Scanner;

public class IfElseOrnek3 {
    public static void main(String[] args) {
//        System.out.println("uc tane int sayi girin");
//        Scanner scan=new Scanner(System.in);
//        int a=scan.nextInt();
//        int b=scan.nextInt();
//        int c=scan.nextInt();
//        System.out.println("Girilin sayilarin toplami " +(a+b+c)+ " dir.");
//        System.out.println("Girilin sayilarin ortalamasi " +(a+b+c)/3+ " dir.");
//

    }
}
