package lessons.gun11;

import org.w3c.dom.ls.LSOutput;

public class DegerAtama {
     public static void main(String[] args) {
          char var1 = 'A';
           char var2 = 'a';
            System.out.println((int)var1 + " " + (int)var2);


          int a = 3;
          System.out.println(a);
          a++; // a yi bir arttirir

          System.out.println(a);
          ++a; // a nin son degerini bir ekler
          System.out.println(a);
          a+=3; // a nin son degerine 3 ekler
          System.out.println(a);
          a+=20;  // a nin son degerine 20 ekler
          a-=10;  // a nin son degerinden 10 cikarir
          System.out.println(a);
          a--; // a nin son degerinden 1 cikarir


     }
}