package lessons.gun11;

public class ornek {
    // --->  merhaba ,hosgeldin, sira numaran kac?
    //-- bir sayi girceksiniz elle
    // -- buyrun siraniza gidin
}
