package lessons.gun11;

public class IfConditionals {
    public static void main(String[] args) {
        System.out.println("1.If blogu==============================================");
        if(2+3==5){
            System.out.println("condition dogru oldugu icin if blogu calisti");
        }
        System.out.println("2.If blogu==============================================");
        if(2+4==5){
            System.out.println("condition yanlis oldugu icin if blogu calismayacak");
            // condition yanlis oldugu icin if blogu calismayacak yani hicbirsey print etmeyecek
        }
        System.out.println("3.If blogu==============================================");



        /*
        if (koşul){
            Kosul saglaninca(true) bu blok calisir
        }

        else{
            bu blogun ustendeki herhaangi kosul saglanmadigi zaman bu blok calisir
        }
       */









//    int sayi=20;
//    if(sayi<20){
//        System.out.println("Sayi 20 den kucuktur");
//    }
//
//    if (sayi<15){
//        System.out.println("Sayi 15 den kucuktur");
//    }
//        System.out.println("========================================================");
//
//    if(sayi<10){
//        System.out.println("Sayi 10 dan kucuktur");
//    }else{
//        System.out.println("sayi 10 dan buyuktur");
//    }
//        System.out.println("========================================================");
//        if(sayi<10){
//            System.out.println("Sayi 10 dan kucuktur");
//        }else if(sayi==10){
//            System.out.println("sayi 10 a esittir");
//        }else{
//            System.out.println("sayi 10 dan buyuktur");
//        }





}}
