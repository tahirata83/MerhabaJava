package lessons.gun11;
import java.util.Scanner;
public class ScannerInput {

    public static void main(String[] args) {
        System.out.println("sifre giriniz");
        Scanner scan=new Scanner(System.in);
        int i=scan.nextInt();
        System.out.println("basarili giris");

        //String s=scan.nextLine();
    }
}
