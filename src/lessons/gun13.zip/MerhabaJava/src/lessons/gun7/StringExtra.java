package lessons.gun7;

public class StringExtra {
    public static void main(String[] args) {

        String s1="Ben okul olarak \"ICHC\" de calisiyorum.";
        System.out.println(s1);
        String s2="Ben okul olarak \'ICHC\' de calisiyorum.";
        System.out.println(s2);
        String s3="Ben okul olarak \\ ICHC de calisiyorum.";
        System.out.println(s3);


    }
}
