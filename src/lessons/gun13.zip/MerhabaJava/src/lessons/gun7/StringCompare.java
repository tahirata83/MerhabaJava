package lessons.gun7;

public class StringCompare {
    public static void main(String[] args) {
        String s1= "Merhaba";
        String s2="Merhaba";



        System.out.println(s1==s2);

        System.out.println(s1.equals(s2));

        String s3= "Tahir";
        String s4="Ata";
        System.out.println(s3.equals(s4));

    }
}
