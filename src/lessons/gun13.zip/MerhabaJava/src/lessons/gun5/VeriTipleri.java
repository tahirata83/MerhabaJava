package lessons.gun5;

public class VeriTipleri {
    public static void main(String[] args) {

//        int a=Integer.MAX_VALUE;     //2147483647
//        System.out.println(a);
//        int b4=Integer.MIN_VALUE;   //-2147483648
//        System.out.println(b4);

//        byte b5= Byte.MAX_VALUE;
//        System.out.println(b5);
//        byte b6= Byte.MIN_VALUE;
//        System.out.println(b6);
//
//
//        short s5= Short.MAX_VALUE;
//        System.out.println(s5);
//        short s6= Short.MIN_VALUE;
//        System.out.println(s6);
//

 //           float f=Float.MAX_VALUE;





        // byte-->short-->int-->long
        System.out.println("=======byte ============================================");
        System.out.println("min deger---->  "+Byte.MIN_VALUE);
        System.out.println("max deger---->  "+Byte.MAX_VALUE);
        System.out.println("=======short ============================================");
        System.out.println("min deger---->  "+Short.MIN_VALUE);
        System.out.println("max deger---->  "+Short.MAX_VALUE);
        System.out.println("=======int ============================================");
        System.out.println("min deger---->  "+Integer.MIN_VALUE);
        System.out.println("max deger---->  "+Integer.MAX_VALUE);
        System.out.println("=======long ============================================");
        System.out.println("min deger---->  "+Long.MIN_VALUE);
        System.out.println("max deger---->  "+Long.MAX_VALUE);
        System.out.println("=======float ============================================");
        System.out.println("min deger---->  "+Float.MIN_VALUE);
        System.out.println("max deger---->  "+Float.MAX_VALUE);
        System.out.println("=======double ============================================");
        System.out.println("min deger---->  "+Double.MIN_VALUE);
        System.out.println("max deger---->  "+Double.MAX_VALUE);

 // 1 byte = 4 bit


//        byte max ve min===============================================================
//       127
//       -128
//        short max ve min===============================================================
//        32767
//      -32768
//       integer max ve min===============================================================
//        2147483647
//        -2147483648
//         long max ve min===============================================================
//       9223372036854775807
//       -9223372036854775808
//
//
//
//        byte b= 5;
//        int i=5670;
//        int sonuc=i/b;
//        System.out.println(sonuc);
//      //  byte sonuc1=i/b;
//      //  System.out.println(sonuc1);
//        // ( java otomatik b yi integer tipine degistiriyor. i yi byte tipine degistiremiyor )
//
//        byte b1=2;
//        short s1=100;
//        int i1=4;
//        long lg1=b1+s1+i1;
//        System.out.println("long l1-->"+lg1);
//
//
//        */

    }
}
