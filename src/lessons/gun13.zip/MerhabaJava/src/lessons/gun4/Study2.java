package lessons.gun4;

public class Study2 {
    public static void main(String[] args) {
//        int a=4;
//        System.out.println(a);


        int a=4;
        a++;
        a+=5;
        a--;
        a-=2;
        System.out.println(a);
        System.out.println("=======================================================================");
        int b=19;   // b=19
        b++;         // b=20
        b+=1;        // b=21
        b+=7;    // b=28
        b-=4;
        b--;
        b-=20;
        System.out.println(b);
        System.out.println("=======================================================================");

        int c=6;  // c=6
        c++;      // c=7
        c+=1;  // c=8
        c+=10;  // c=18

        c--;   // c=17
        c-=1;  // c=16
        c-=10;  // c=6

        c=c+1;  // c++// c+=1;
        c=c-3;
        System.out.println(c);



    }
}