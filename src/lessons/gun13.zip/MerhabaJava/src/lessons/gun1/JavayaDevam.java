package lessons.gun1;

public class JavayaDevam {
}
