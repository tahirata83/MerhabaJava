package lessons.gun1;

public class Asa {
    public static void main(String[] args) {
        int a=3;
    }
}
