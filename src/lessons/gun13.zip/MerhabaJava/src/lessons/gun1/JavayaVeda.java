package lessons.gun1;

public class JavayaVeda {


}
