package lessons.gun1;

public class Sinif {


    public static void main(String[] args) {
        int a=335353;
        int b=436533;
        int topla= a+b;



       // System.out.println(topla);

        System.out.print("Tahir");

        System.out.print(7);

    }
}
