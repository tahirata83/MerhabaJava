package lessons.gun1;

public class MerhabaJava {

    public static void main(String[] args) {
        // main metodu

        int a= 3;
        String word="java";

        System.out.println(a+word);

    }

}
   // JVM
    // JRE
  //JDK

