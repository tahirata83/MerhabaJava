package lessons.gun10;

public class Homework {
    //    1. Short veri tipinin araliklari hangisidir?
//    a) -128 to 127
//    b) -32768 to 32767     (cevap)
//    c) -2147483648 to 2147483647
//    d) None of the mentioned
//
//
//
//    2. Byte veri tipinin araliklari hangisidir?
//    a) -128 to 127   (cevap)
//    b) -32768 to 32767
//    c) -2147483648 to 2147483647
//    d) None of the mentioned
//    View Answer
//
//
//
//    3. hangi kod syntaxe gore dogru yazilmistir?
//    1. int w = (int)888.8;   (cevap)
//    2. byte x = (byte)100L; -- long u byte ceviremez
//    3. long y = (byte)100;  --- long a cevirirken (long)
//    4. byte z = (byte)100L; ----long u byte ceviremez

//    a) 1 and 2       (?)
//    b) 2 and 3
//    c) 3 and 4
//    d) All statements are correct.
//
//
//
//    bu Kod ne print eder?
//
//    class increment {
//        public static void main(String args[])
//        {
//            int g = 3;

//            System.out.print(++g * 8);
//        }
//    }
//    a) 25
//    b) 24
//    c) 32 (cevap)
//    d) 33
//
//
//     bu kod ne print eder?
//
//    class area {
//        public static void main(String args[])
//        {
//            double r, pi, a;
//            r = 91;
//            pi = 3.14;
//            a = pi * r * r;
//            System.out.println(a);
//        }
//    }
//    a) 301.5656  (cevap)
//    b) 301
//    c) 301.56
//    d) 301.56560000


    //    char veri tipinin araliklari hangisidir?
//    a) -128 to 127
//    b) 0 to 256
//    c) 0 to 32767
//    d) 0 to 65535 (cevap)
//
//
//    bu kod ne print eder?
//
//    class mainclass {
//        public static void main(String args[])
//        {
//            char a = 'A';
//            a++;
//            System.out.print((int)a);
//        }
//    }
//    a) 66 (cevap)
//    b) 67
//    c) 65
//    d) 64
//
//
//    bu kod ne print eder?
//
//    class asciicodes {
//        public static void main(String args[])
//        {
//            char var1 = 'A';
//            char var2 = 'a';
//            System.out.println((int)var1 + " " + (int)var2);
//        }
//    }
//    a) 162
//    b) 65 97  (cevap)
//    c) 67 95
//    d) 66 98


}
