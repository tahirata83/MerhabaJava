package lessons.gun6;

public class Ornek {
    public static void main(String[] args) {

        int chr = 'Z';
        System.out.println("The ASCII value of Z is :"+chr);

        char ch1 ='Z';
        System.out.println(ch1);

        int deger='M';
        System.out.println(deger);


        String s1 = "techno study";
        //to convert to uppercase TECHNO STUDY use toUpperCase();
        System.out.println("sonuc   "+s1.toUpperCase());

    }
}
