package lessons.gun6;

public class VeriTipleriBooleanChar {
    public static void main(String[] args) {


     boolean b1=false;
     boolean b2=true;
        System.out.println(b1);
        System.out.println(b2);

        System.out.println(true);
        System.out.println(false);
        System.out.println(true&&true);

        System.out.println(" Ve-- ihtimalleri=================================================================");
        System.out.println(false&&true);
        System.out.println(true&&false);
        System.out.println(false&&false);
        System.out.println(true&&true);
        System.out.println(" Veya-- ihtimalleri=================================================================");
        System.out.println(false||true);
        System.out.println(true||false);
        System.out.println(false||false);
        System.out.println(true||true);

        System.out.println("=================================================");

        int i1=3;
        int i2 =45;
        System.out.println((i1<0)&&(i2>20));
        System.out.println((i1<0)||(i2>20));
        System.out.println(2<7);
        System.out.println(7<2);

        System.out.println(0/0==0);

//         int i3=120;
//        if(i3<10){
//            System.out.println("dogru");
//        }




//
//        String s= "yazilim";
//       /*
//          username:tahirata
//          password:ichc2010
//
//        */
//        String hata="ichc2010";
//        System.out.println(hata+"!");
//
//        // sonuna ! ekleyin
//        //
//
//          char ch='!';
//          String s2="selam";
//
//
//
//
//
//
//        char karakter ='+';
//        karakter='-';
//        char c1='a';
//        //her char karakterinin arka tarafta unicode dedigimiz sayi degeri vardir
//        System.out.println(karakter);
//        System.out.println(c1);
//
//
//
//
////
////        boolean b1= false;
////        boolean b2= true;
////        System.out.println(b1);
////        System.out.println(b2);
//
//
////        boolean sonuc1=b1&b2;
////        System.out.println(sonuc1);
////        boolean sonuc2=b2&b1;
////        System.out.println(sonuc2);
////        boolean sonuc3=b1&b1;
////        System.out.println(sonuc3);
////        boolean sonuc4=b2&b2;
////        System.out.println(sonuc4);
//
////
////        boolean sonuc5=b1||b2;
////        System.out.println(sonuc5);
////        boolean sonuc6=b2||b1;
////        System.out.println(sonuc6);
////        boolean sonuc7=b1||b1;
////        System.out.println(sonuc7);
////        boolean sonuc8=b2||b2;
////        System.out.println(sonuc8);
//
//
//
//      int a=0;
//


       String a1="3";
      int b3=Integer.parseInt(a1);


    }
}
